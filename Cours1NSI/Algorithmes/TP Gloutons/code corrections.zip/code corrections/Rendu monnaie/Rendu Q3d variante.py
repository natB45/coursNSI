def rendu_monnaie(jeu_pieces, s):
    """Fonction donnant la liste des pièces et billets à rendre pour obtenir un
    montant donné et le nombre de pièces ou billets que cela représente.
    entrées :
       - jeu_pieces est un tableau (type list) des montants des pièces et billets
       disponibles pour rendre la monnaie ;
       - s est un entier positif (type int) représentant la somme à rendre.
    sorties :
       - rendu est un tableau (type list) donnant les valeurs des pièces et billets
       à rendre ;
       - nb_pieces est un entier positif (type int) indiquant le nombre de pièces
       ou billets rendus."""
    rendu = []
    nb_pieces = 0
    i = 0
    while s > 0:
        while jeu_pieces[i] > s:
            i = i +1
            #on regarde si on a essayé toutes les valeurs du tableau
            if i == len(jeu_pieces):
                return "Impossible de rendre la monnaie !"
        s = s - jeu_pieces[i]
        rendu.append(jeu_pieces[i])
        nb_pieces = nb_pieces + 1
    return rendu, nb_pieces

#tests
jeu = [200, 100, 50, 20, 10, 5, 2, 1]

assert rendu_monnaie(jeu, 0) == ([], 0)
assert rendu_monnaie(jeu, 1) == ([1], 1)
assert rendu_monnaie(jeu, 9) == ([5, 2, 2], 3)
assert rendu_monnaie(jeu, 27) == ([20, 5, 2], 3)
assert rendu_monnaie(jeu, 63) == ([50, 10, 2, 1], 4)
assert rendu_monnaie([5, 2], 8) == "Impossible de rendre la monnaie !"
