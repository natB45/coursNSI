#Données du problème, sous forme d'une liste de listes, avec le nom des vidéos (str),
#leur durée en minutes (int) et la taille des fichiers en Go (float).
videos = [["video1", 114, 4.57], ["video2", 32, 0.63], ["video3", 20, 1.65],
          ["video4", 4, 0.085], ["video5", 18, 2.15], ["video6", 80, 2.71],
          ["video7", 5, 0.32]]
