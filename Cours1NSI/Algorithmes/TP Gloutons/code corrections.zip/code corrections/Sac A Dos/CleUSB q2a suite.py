#Données du problème, sous forme d'une liste de listes, avec le nom des vidéos (str),
#leur durée en minutes (int) et la taille des fichiers en Go (float).
videos = [["video1", 114, 4.57], ["video2", 32, 0.63], ["video3", 20, 1.65],
          ["video4", 4, 0.085], ["video5", 18, 2.15], ["video6", 80, 2.71],
          ["video7", 5, 0.32]]

def cle_USB(liste_fichiers,taille_max):
    """Fonction donnant la liste des vidéos à placer sur la clé USB, en utilisant leur durée
    pour faire les choix.
    entrées :
       liste_fichiers est une liste de listes (list), repésentant les vidéos disponibles
       taille_max est un entier positif (int) représentant la place disponible sur le clé en Go
    sorties :
       reponse est une liste (list) des vidéos à placer sur la clé USB
       duree_totale est un entier (int) représentant la durée totale en minutes de ces vidéos
    """
    liste = sorted(liste_fichiers, key = lambda liste_fichiers : liste_fichiers[1], reverse = True)
    #liste des vidéos à placer sur la clé
    reponse = []
    #durée totale des vidéos placées sur la clé
    duree_totale = 0
    #taille totale des vidéos placées sur la clé
    taille_totale = 0
    #indice de parcours de la liste des fichiers disponibles
    i = 0
    #tant que la taille totale ne dépasse la place disponible sur la clé et que
    #l'indice ne dépasse pas l'indice maximal de la liste
    while taille_totale <= taille_max and i < len(liste):
        nom_video = liste[i][0]    #on récupère le nom de la vidéo
        duree_video = liste[i][1]   #on récupère la durée de la vidéo
        taille_video = liste[i][2]   #on récupère la taille de la vidéo
        #si il reste suffisamment de place pour ajouter cette vidéo
        if taille_totale + taille_video <= taille_max:
            reponse.append(nom_video)   #on ajoute la vidéo à la liste reponse
            duree_totale = duree_totale + duree_video   #on calcule la nouvelle durée totale
            taille_totale = taille_totale + taille_video  #on calcule la nouvelle taille totale
        i = i +1  #on regarde l'élément suivant de la liste
    return reponse, duree_totale

print(cle_USB(videos, 5))