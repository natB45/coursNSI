#Données du problème, sous forme d'une liste de listes, avec le nom des vidéos (str),
#leur durée en minutes (int) et la taille des fichiers en Go (float).
videos = [["video1", 114, 4.57], ["video2", 32, 0.63], ["video3", 20, 1.65],
          ["video4", 4, 0.085], ["video5", 18, 2.15], ["video6", 80, 2.71],
          ["video7", 5, 0.32]]

def cle_USB2(liste_fichiers,taille_max):
    """Fonction donnant la liste des vidéos à placer sur la clé USB, en utilisant le rapport
    durée/taille pour faire les choix.
    entrées :
       liste_fichiers est une liste de listes (list), repésentant les vidéos disponibles
       taille_max est un entier positif (int) représentant la place disponible sur le clé en Go
    sorties :
       reponse est une liste (list) des vidéos à placer sur la clé USB
       duree_totale est un entier (int) représentant la durée totale en minutes de ces vidéos
    """
    #on classe les fichiers par ordre décroissant des rapports durée/taille de la vidéo
    liste = sorted(liste_fichiers, key = lambda liste_fichiers : liste_fichiers[1]/liste_fichiers[2], reverse = True)
    reponse = []
    duree_totale = 0
    taille_totale = 0
    i = 0
    while taille_totale <= taille_max and i < len(liste):
        nom_video = liste[i][0]
        duree_video = liste[i][1]
        taille_video = liste[i][2]
        if taille_totale + taille_video <= taille_max:
            reponse.append(nom_video)
            duree_totale = duree_totale + duree_video
            taille_totale = taille_totale + taille_video
        i = i +1
    return reponse, duree_totale


print(cle_USB2(videos, 5))

