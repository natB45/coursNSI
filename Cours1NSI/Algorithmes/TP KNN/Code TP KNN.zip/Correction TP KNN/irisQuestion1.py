#Algorithme des KNN
#Etude du fichier iris

#question 4.1)
import csv                 #module pour travailler avec les fichiers csv
from math import sqrt      #fonction racine carré du module math
from random import shuffle #fonction permettant de mélanger les éléments d'une liste

def lecture_donnees(nom_fichier):
    """
    Permet de charger un fichier CSV
    paramètre : nom_fic une chaine de caractères contenant le nom du fichier csv
    résultat : la liste des enregistrements dans le fichier (une liste de listes)
    """
    liste_enreg = []
    with open (nom_fichier, "r", newline="", encoding = "utf-8") as csvfile :
    # création du lecteur csv
        fich_reader = csv.reader(csvfile, delimiter = ",")
        for enreg in fich_reader :
            #enreg est de type list
            #Le premier étant l'entête sous forme d'une liste
            liste_enreg.append(enreg)
    #on supprime le premier élément comportant le nom des champs du fichier
    del(liste_enreg[0])
    #on transforme les 4 premiers éléments de la liste en réels
    for element in liste_enreg:
        for i in range(4):
            element[i] = float(element[i])
    return liste_enreg

iris = lecture_donnees("iris.csv")

assert iris[0][4] == 'Iris-setosa'
assert iris[65][0] == 6.7
assert iris[65][1] == 3.1
assert iris[65][2] == 4.4
assert iris[65][3] == 1.4

