#Algorithme des KNN
#Etude du fichier iris

#question 4.1)
import csv                 #module pour travailler avec les fichiers csv
from math import sqrt      #fonction racine carré du module math
from random import shuffle #fonction permettant de mélanger les éléments d'une liste

def lecture_donnees(nom_fichier):
    """
    Permet de charger un fichier CSV
    paramètre : nom_fic une chaine de caractères contenant le nom du fichier csv
    résultat : la liste des enregistrements dans le fichier (une liste de listes)
    """
    liste_enreg = []
    with open (nom_fichier, "r", newline="", encoding = "utf-8") as csvfile :
    # création du lecteur csv
        fich_reader = csv.reader(csvfile, delimiter = ",")
        for enreg in fich_reader :
            #enreg est de type list
            #Le premier étant l'entête sous forme d'une liste
            liste_enreg.append(enreg)
    #on supprime le premier élément comportant le nom des champs du fichier
    del(liste_enreg[0])
    #on transforme les 4 premiers éléments de la liste en réels
    for element in liste_enreg:
        for i in range(4):
            element[i] = float(element[i])
    return liste_enreg

iris = lecture_donnees("iris.csv")

#question 4.2)
def jeux_donnees(p, donnees):
    """Fonction séparant le jeu de données en deux jeux : un d'entrainement et
    l'autre de test.
    entrées : p réel idiquant le pourcentage de données du jeu à réserver pour
     le jeu d'entrainement donnees qui correspond à la liste du jeu de données
    sorties : un tuple de deux listes comportant les indices des éléments du
     jeu d'entrainement et ceux du jeu de test
    """
    #taille de la liste de donnees
    nombre_donnees = len(donnees)
    #calcul du nombre de données à réserver pour le jeu d'apprentissage
    p = p*nombre_donnees//100
    #création d'une liste comportant les indices de la liste de données
    liste_indices = [i for i in range(nombre_donnees)]
    #mélange des indices
    shuffle(liste_indices)
    #les p premiers indices sont ceux du jeu d'entrainement
    indices_entrainement = liste_indices[0:p]
    #le reste des indices sont ceux du jeu de test
    indices_test = liste_indices[p:]
    return indices_entrainement, indices_test

train, test = jeux_donnees(30, iris)