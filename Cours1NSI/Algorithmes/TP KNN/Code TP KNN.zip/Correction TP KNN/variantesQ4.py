#Algorithme des KNN
#Etude du fichier iris

#question 4.1)
import csv                 #module pour travailler avec les fichiers csv
from math import sqrt      #fonction racine carré du module math
from random import shuffle #fonction permettant de mélanger les éléments d'une liste

def lecture_donnees(nom_fichier):
    """
    Permet de charger un fichier CSV
    entrée : nom_fic une chaine de caractères contenant le nom du fichier csv
    sortie : la liste des enregistrements dans le fichier (une liste de listes)
    """
    liste_enreg = []
    with open (nom_fichier, "r", newline="", encoding = "utf-8") as csvfile :
    # création du lecteur csv
        fich_reader = csv.reader(csvfile, delimiter = ",")
        for enreg in fich_reader :
            #enreg est de type list
            #Le premier étant l'entête sous forme d'une liste
            liste_enreg.append(enreg)
    #on supprime le premier élément comportant le nom des champs du fichier
    del(liste_enreg[0])
    #on transforme les 4 premiers éléments de la liste en réels
    for element in liste_enreg:
        for i in range(4):
            element[i] = float(element[i])
    return liste_enreg

iris = lecture_donnees("iris.csv")

#question 4.2)
def jeux_donnees(p, donnees):
    """Fonction séparant le jeu de données en deux jeux : un d'entrainement et
    l'autre de test.
    entrées : p réel idiquant le pourcentage de données du jeu à réserver pour
     le jeu d'entrainement donnees qui correspond à la liste du jeu de données
    sorties : un tuple de deux listes comportant les indices des éléments du
     jeu d'entrainement et ceux du jeu de test
    """
    #taille de la liste de donnees
    nombre_donnees = len(donnees)
    #calcul du nombre de données à réserver pour le jeu d'apprentissage
    p = p*nombre_donnees//100
    #création d'une liste comportant les indices de la liste de données
    liste_indices = [i for i in range(nombre_donnees)]
    #mélange des indices
    shuffle(liste_indices)
    #les p premiers indices sont ceux du jeu d'entrainement
    indices_entrainement = liste_indices[0:p]
    #le reste des indices sont ceux du jeu de test
    indices_test = liste_indices[p:]
    return indices_entrainement, indices_test

#question 4.3)
def distance(x,y):
    """Fonction qui calcule la distance euclidienne entre deux points.
    entrée : deux listes de réels, de mêmes tailles
    sortie : un réel égal à la distance euclidienne entre x et y
    """
    somme = 0
    for i in range(len(x)):
        #on fait la somme du carré des écarts
        somme = somme + (x[i]-y[i])**2
    #on prend la racine carré du résultat
    return sqrt(somme)

def lePlusProcheVoisin(x,entrainement,donnees):
    """Fonction donnant l'indice de l'élément le plus proche de x parmi les iris
    du jeu d'entrainement.
    entrées : x une liste de quatre réels correspondant aux mesures d'une iris ;
       entrainement correspondant à la liste des indices du jeu d'entrainement ;
       donnees la liste du jeu de données iris.
    sortie : l'indice de l'élément du jeu d'entrainement le plus proche de x
    """
    #initialisation avec le premier indice de la liste entrainement
    indice_du_plus_proche = entrainement[0]
    #initialisation avec le premier élément du jeu d'entrainement
    distance_min = distance(x, donnees[indice_du_plus_proche][0:4])
    #on calcule la distance avec chaque élément du jeu d'entrainement
    for indice in entrainement:
        #si celle-ci est plus petite on change l'indice et la distance minimale
        if distance(x, donnees[indice][0:4]) < distance_min:
            indice_du_plus_proche = indice
            distance_min = distance(x, donnees[indice][0:4])
    return indice_du_plus_proche

#question 4.4)
def lesKplusProchesVoisins(x, k , donnees, entrainement):
    """Fonction qui permet de déterminer les k plus proches voisins de x dans
     le jeu d'apprentissage.
     Entrées : x une liste comportant les 4 descripteurs de l'iris ; k le nombre
     entier positif désignant le nombre de voisins souhaités ; donnees le jeu de
     données iris sous forme d'une liste de listes et entrainement la liste des
     indices des éléments du jeu d'entrainement.
     sortie : la liste des indices des k plus proches voisins
    """
    k_indices =[]
    for i in range(k):
        n = lePlusProcheVoisin(x, entrainement, donnees)
        #on ajoute l'indice de plus proche voisin
        k_indices.append(n)
        #on garde tous les éléments de la liste entrainement, sauf n
        entrainement = [indice for indice in entrainement if indice != n]
    return k_indices

#on cherche les 3 plus proches voisins de x =[5, 3, 3, 2] sur tout le jeu de données iris
assert lesKplusProchesVoisins([5, 3, 3, 2], 3 , iris, [i for i in range(150)]) == [98, 64, 59]


#variante
def lesKplusProchesVoisins2(x, k , donnees, entrainement):
    """Fonction qui permet de déterminer les k plus proches voisins de x dans
     le jeu d'apprentissage.
     Entrées : x une liste comportant les 4 descripteurs de l'iris ; k le nombre
     entier positif désignant le nombre de voisins souhaités ; donnees le jeu de
     données iris sous forme d'une liste de listes et entrainement la liste des
     indices des éléments du jeu d'entrainement.
     sortie : la liste des indices des k plus proches voisins
    """
    k_indices =[]
    for i in range(k):
        n = lePlusProcheVoisin(x, entrainement, donnees)
        k_indices.append(n)
        #on retire l'élément n de la liste entrainement
        entrainement.remove(n)
    return k_indices

#variante2
def lesKplusProchesVoisins3(x, k , donnees, entrainement):
    """Fonction qui permet de déterminer les k plus proches voisins de x dans
     le jeu d'apprentissage.
     Entrées : x une liste comportant les 4 descripteurs de l'iris ; k le nombre
     entier positif désignant le nombre de voisins souhaités ; donnees le jeu de
     données iris sous forme d'une liste de listes et entrainement la liste des
     indices des éléments du jeu d'entrainement.
     sortie : la liste des indices des k plus proches voisins
    """
    k_indices =[]
    for i in range(k):
        n = lePlusProcheVoisin(x, entrainement, donnees)
        k_indices.append(n)
        #on retire l'élément n de la liste entrainement
        #del entrainement[indice dans entrainement de l'élément n]
    return k_indices