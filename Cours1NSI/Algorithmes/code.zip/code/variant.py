def quotient(n):
    q = 0
    while n >= 3:
        n = n - 3
        q = q + 1
    return(q)