ma_liste = [x-3 for x in range(10) if x%3 == 0]
