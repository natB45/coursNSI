def change(mot):
    reponse = ""
    for i in range(len(mot)):
        reponse = mot[i] + reponse
    return reponse