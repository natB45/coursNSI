repertoire = [{"nom" : "Gibson", "tel" : "0630465415"},
 {"nom" : "Mars", "tel" : "06574544555"}, {"nom" : "Strabuck", "tel" : "0611458799"}]