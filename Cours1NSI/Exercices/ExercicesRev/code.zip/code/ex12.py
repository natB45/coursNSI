repertoire = [{"nom" : "Gibson", "tel" : "0630465415"},
 {"nom" : "Mars", "tel" : "06574544555"}, {"nom" : "Strabuck", "tel" : "0611458799"}]

inconnue = list(repertoire[2].values())

who = repertoire[0].keys()