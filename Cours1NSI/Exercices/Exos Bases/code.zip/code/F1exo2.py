a = input("saisir un nombre : ")
print("le nombre suivant est ",a+1)