n = int(input("combien d'oeufs :"))
print(n//6)

