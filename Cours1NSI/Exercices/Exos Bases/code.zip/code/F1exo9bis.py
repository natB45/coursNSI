n = int(input("combien d'oeufs :"))
if n%6 == 0:
    print(n//6)
else:
    print(n//6+1)
