def appartenir(mot,lettre):
    """Indique si la lettre donnée est présente au moins une fois dans le mot."""
    for l in mot:
        if l.lower() == lettre.lower():  #tout écrire en minuscules
            return True
    return False

def appartenir_bis(mot,lettre):
    for i in range(len(mot)):
        if mot[i].lower() == lettre.lower():  #tout écrire en minuscules
            return True
    return False

assert appartenir("appartement","t") == True
assert appartenir("lunettes","a") == False
assert appartenir("Fauve","f") == True
assert appartenir("aile","") == False