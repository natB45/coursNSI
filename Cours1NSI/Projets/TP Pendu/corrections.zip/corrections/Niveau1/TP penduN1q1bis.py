def appartenir(mot,lettre):
    """Indique si la lettre donnée est présente au moins une fois dans le mot."""
    for l in mot.lower():
        if l == lettre.lower():  #tout écrire en minuscules
            return True
    return False

def appartenir_bis(mot,lettre):
    m = mot.lower()
    for i in range(len(mot)):
        if m[i]== lettre.lower() :  #tout écrire en minuscules
            return True
    return False

assert appartenir_bis("appartement","t") == True
assert appartenir_bis("lunettes","a") == False
assert appartenir_bis("Fauve","f") == True
assert appartenir_bis("aile","") == False