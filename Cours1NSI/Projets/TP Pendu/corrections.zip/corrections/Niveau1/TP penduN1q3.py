def affiche_mot(mot,liste_lettres):
    """Fonction qui renvoie le mot avec les lettres du mot présentes dans la liste à leur place
    et des tirets pour les autres.
    entrées : le mot (str) ; la liste des lettres (list)
    sortie : un mot constitué de tirets et de lettres (str)
    """
    new_mot = ["-"]*(len(mot))     #création d'une liste de tirets de la longueur du mot
    for l in liste_lettres:
        for i in range(len(mot)):
            if l == mot[i]:        #si la lettre est dans le mot, on remplace le tiret
                new_mot[i] = l
    chaine =""                     #on transforme la liste en chaine de caractère
    for element in new_mot:
        chaine = chaine + element
    return chaine

#Testez la fonction
assert affiche_mot("pistoler",["p","t","o"]) == "p--to---"
assert affiche_mot("pomme",["m"]) == "--mm-"
assert affiche_mot("arbre",["o","c"]) == "-----"
assert affiche_mot("chat",[]) == "----"
assert affiche_mot("tiens",['e','t','y','e']) == "t-e--"