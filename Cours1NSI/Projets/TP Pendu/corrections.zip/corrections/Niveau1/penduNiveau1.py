"""Ce programme permet de jouer au pendu. L'ordinateur choisi un mot au hasard
   dans un fichier texte de mots de 7 lettres, puis il représente le mot avec des tirets.
   On a droit à 6 erreurs au maximum.
"""
__author__ = ("Nathalie Bessonnet")
__date__ = "12/04/2020"

from random import randint

def appartenir(mot,lettre):
    """Indique si la lettre donnée est présente au moins une fois dans le mot."""
    for l in mot:
        if l.lower() == lettre.lower():  #tout écrire en minuscules
            return True
    return False


def choix(fichier):
    """Fonction qui crée une liste de mots obtenus dans le fichier,
    puis en retourne un au hasard, sous forme d'une chaîne de caractères"""
    liste_mots = []
    with open(fichier,'r') as mon_fichier:
        for mot in mon_fichier:
            liste_mots.append(mot.rstrip('\n\r'))
    n = len(liste_mots)
    indice_mot = randint(0,n-1)
    return liste_mots[indice_mot]

def affiche_mot(mot,liste_lettres):
    """Fonction qui renvoie le mot avec les lettres du mot présentes dans la liste à leur place
    et des tirets pour les autres.
    entrées : le mot (str) ; la liste des lettres (list)
    sortie : un mot constitué de tirets et de lettres (str)
    """
    new_mot = ["-"]*(len(mot))     #création d'une liste de tirets de la longueur du mot
    for l in liste_lettres:
        for i in range(len(mot)):
            if l == mot[i]:        #si la lettre est dans le mot, on remplace le tiret
                new_mot[i] = l
    chaine =""                     #on transforme la liste en chaine de caractère
    for element in new_mot:
        chaine = chaine + element
    return chaine


#Ici commence le programme principal
if __name__ == "__main__":
    mot_a_deviner = choix("words.txt")   #on choisi le mot à faire deviner
    print(affiche_mot(mot_a_deviner,[])) #on affiche les tirets
    echecs = 0                  #nombre de lettres proposées n'appartenant pas au mot
    trouver = False             #booléen indiquant si le mot a été deviné
    liste_propositions = []     #liste des lettres proposées
    while trouver == False and echecs != 6:   #tant que l'on n'a pas trouvé et qu'il y a moins de 6 échecs
        proposition = input("Quelle lettre proposez-vous ? ")
        liste_propositions.append(proposition)
        affichage = affiche_mot(mot_a_deviner,liste_propositions)  #on a trouvé une lettre, on recupère le mot complété
        if appartenir(mot_a_deviner,proposition):
            if affichage == mot_a_deviner:     #si il n'y a plus de tirets, on a gagné, la boucle s'arrête
                trouver = True
        else:
            echecs += 1                    #la lettre n'est pas dans le mot, le compteur des echecs augmente
            print("Cette lettre n'est pas présente !")
        print(affichage)                   #on affiche le mot avec des tirets et les lettres déjà trouvées
    if trouver == True:                    #on regarde si on trouvé le mot ou si l'on a fait trop de tentatives
        print("Bien joué, vous avez trouvé le mot", mot_a_deviner)
    else:
        print("Vous voilà pendu ! Il fallait trouver le mot ", mot_a_deviner)