"""Ce programme permet de jouer au pendu. L'ordinateur choisi un mot au hasard
   dans un fichier texte de mots de 7 lettres, puis il représente le mot avec des tirets.
   On a droit à 6 erreurs au maximum.
"""
__author__ = ("Nathalie Bessonnet")
__date__ = "12/04/2020"

from random import randint

def appartenir(mot,lettre):
    """Indique si la lettre donnée est présente au moins une fois dans le mot."""
    for l in mot:
        if l.lower() == lettre:
            return True
    return False

def choix(fichier):
    """Fonction qui crée une liste de mots obtenus dans le fichier,
    puis en retourne un au hasard, sous forme d'une chaîne de caractères"""
    liste_mots = []
    with open(fichier,'r') as mon_fichier:
        for mot in mon_fichier:
            liste_mots.append(mot.rstrip('\n\r'))
    n = len(liste_mots)
    indice_mot = randint(0,n-1)
    return liste_mots[indice_mot]

def affiche_mot(mot,liste_lettres):
    """Fonction qui renvoie le mot avec les lettres du mot présentes dans la liste à leur place
    et des tirets pour les autres.
    entrées : le mot (str) ; la liste des lettres (list)
    sortie : un mot constitué de tirets et de lettres (str)
    """
    new_mot = ["-"]*(len(mot))
    for l in liste_lettres:
        for i in range(len(mot)):
            if l == mot[i]:
                new_mot[i] = l
    chaine =""
    for element in new_mot:
        chaine = chaine + element
    return chaine


if __name__ == "__main__":
    print("Vous devez proposer des lettres, sans accent, pour deviner un mot choisi au hasard. Vous avez droit à 6 erreurs maximum.")
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    continuer = True         #un booléen qui reste vrai tant que le joueur veut continuer
    while continuer:
        mot_a_deviner = choix("words.txt")
        print(affiche_mot(mot_a_deviner,[]))
        echecs = 0
        trouver = False
        liste_propositions = []
        while trouver == False and echecs != 6:
            proposition = input("Quelle lettre proposez-vous ? ")
            while proposition not in alphabet:
                proposition = input("Attention, proposition non valide. Donnez une nouvelle lettre : ")
            liste_propositions.append(proposition)
            affichage = affiche_mot(mot_a_deviner,liste_propositions)
            if appartenir(mot_a_deviner,proposition):
                print("Voici les lettres déjà proposées :",liste_propositions)
                print(affichage)
                if affichage == mot_a_deviner:
                    trouver = True
            else:
                echecs += 1
                print("Cette lettre n'est pas présente !")
                print("Voici les lettres déjà proposées :",liste_propositions)
                print(affichage)
            print("Vous avez fait", echecs, "erreurs.")
        if trouver == True:
            print("Bien joué, vous avez trouvé le mot", mot_a_deviner)
        else:
            print("Vous voilà pendu ! Il fallait trouver le mot ", mot_a_deviner)
        jouer = input ("Voulez-vous rejouer ? o/n ")  #on demande au joueur s'il souhaite faire une nouvelle partie
        if jouer.lower() == "n":
            continuer = False        #le joueur souhaite arrêter, la variable arrête la boucle principale

