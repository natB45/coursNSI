import csv

def charger_scores(nom_fichier):
    """Charger les scores du jeu en une liste de dictionnaires"""
    table = []
    with open(nom_fichier,"r", newline="", encoding = "utf-8") as csvfile :
        element_reader = csv.DictReader(csvfile, delimiter = ";")
        for joueur in element_reader :
            table.append(dict(joueur))
        for dico in table:
            dico["victoires"] = int(dico["victoires"])
            dico["nbre_parties"] = int(dico["nbre_parties"])
    return table