def enregistrer_score(nom_fichier,joueur):
    """Ajouter un nouveau joueur dans le fichier, ou bien modifier les scores d'un joueur
    entrées : fichier csv des scores et dictionnaire représentant une partie faite par un joueur à ajouter au fichier
    sortie : le fichier csv est modifié"""
    liste_scores = charger_scores(nom_fichier)
    if liste_scores == []:                  #la liste des scores est vide, on ajoute le premier joueur
        liste_scores.append(joueur)
    else:
        present = False      #booléen permettant de savoir si on a trouvé le joueur dans la liste des scores
        for dico in liste_scores:
            if dico["nom"] == joueur["nom"]:    #on cherche le joueur dans la liste
                if joueur["victoires"] == 1:    #le joueur a gagné la partie
                    dico["victoires"] = dico["victoires"] + 1
                    dico["nbre_parties"] = dico["nbre_parties"] + 1
                else:
                    dico["nbre_parties"] = dico["nbre_parties"] + 1    #le joueur a perdu sa partie
                present = True    #le joueur était déjà inscrit
        if present is not True:   #le joueur n'est pas inscrit
            liste_scores.append(joueur)
    #on en registre la liste dans le fichier csv
    with open(nom_fichier, "w", newline ="", encoding = "utf-8") as csvfile:
        #on précise les entêtes du fichier
        liste_writer = csv.DictWriter(csvfile, fieldnames = ["nom", "victoires", "nbre_parties"], delimiter = ";")
        liste_writer.writeheader()
        for dico in liste_scores :
            liste_writer.writerow(dico)
    return None