import tkinter

#fonction appelée lorsque l'on clique sur le boutton
def coucou():
    print("Coucou !")
    pass

def change():
    #on récupère le nombre entré
    nombre = zone_text.get()
    if nombre == "1":  #on modifie le texte central
        centre.config(text = "Et Un !")
    elif nombre == "2":
        centre.config(text = "Et Deux !")
    else:
        centre.config(text = "Et Trois Zéro !")

#Mise en place de la fenêtre graphique
fenetre = tkinter.Tk()
fenetre.title("Bienvenue !")
fenetre.geometry("800x600")

#Titre au centre de la fenêtre
centre = tkinter.Label(fenetre, text = "Titre Principal", fg = "Blue", font = ('courier',20))
centre.place(x = 220, y = 250)

#Boutton sur lequel cliquer
bouton = tkinter.Button(fenetre, text = "CLiquez ici !", command = coucou)
bouton.place(x = 700, y = 550)

#Zone où l'on peut taper du texte
zone_text = tkinter.Entry(fenetre, bg = "red", width = 5)
zone_text.place(x = 20, y = 40)

#Afficher un message indiquant quoi taper
description = tkinter.Label(fenetre, text = "Tapez 1 2 ou 3", fg = "Black",font = 20)
description.place(x = 10, y = 10)

#bouton pour valider le choix
bouton2 = tkinter.Button(fenetre, text = "Valider", command = change)
bouton2.place(x = 15, y = 70)



fenetre.mainloop()