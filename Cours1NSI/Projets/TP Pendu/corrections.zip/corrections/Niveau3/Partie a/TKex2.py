import tkinter
import time
import random

def mouve(objet,x1,y1):
    deltax = 3         #décalage sur l'axe des abscisses
    couleurs = ["blue","red","yellow"]
    while x1 <= 800:    #Tant qu'on ne sort pas de la fenetre
        time.sleep(0.05)   #On met le programme en pause 0,02 secondes pour avoir le temps de visualiser le déplacement
        x1 = x1 + deltax   #on modifie l'abscisse du rond
        can.coords(objet,x1,y1,x1+50,y1+50)
        coul = random.randint(0,2)   #on choisi une couleur au hasard dans la liste
        can.itemconfig(objet, fill= couleurs[coul])  #on change la couleur de remplissage
        can.update()      #on met à jour l'affichage


fenetre = tkinter.Tk()
fenetre.title("Canvas")
fenetre.geometry("800x600")
#On pose un caneva sur la fenetre, pour dessiner dessus
can = tkinter.Canvas(fenetre, width = 800, height = 600, bg = "black")
can.place(x = -2, y = 0)
#On trace un rectangle
rec = can.create_rectangle(200, 100, 400, 200, width = 2, outline = "white", fill = "red")
#on trace un cercle
rond = can.create_oval(500, 150, 550, 200, width = 2, outline = "white", fill = "blue")
#on écrit un texte
texte = can.create_text(100, 500, text = "Voici Titeuf", fill = "green", font = (50))
#on charge une image
fichier_img = tkinter.PhotoImage(file = "titeuf.gif")
#on place l'image sur le canevas
titeuf = can.create_image(200, 400, image = fichier_img)

#on déclenche le mouvement du rond
mouve(rond,0, 200)
fenetre.mainloop()