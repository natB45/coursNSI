import tkinter

def couleur(evt):
    abs = evt.x   #on récupère l'abscisse du pointeur de la souris
    ord = evt.y   #on récupère l'ordonnée
    if abs < 400:  #on change la couleur du canevas suivant la zone choisie
        if ord < 300:
            can.config(bg="red")
        else:
            can.config(bg="green")
    else:
        if ord < 300:
            can.config(bg="yellow")
        else:
            can.config(bg="gray")

fenetre = tkinter.Tk()
fenetre.title("Canvas")
fenetre.geometry("800x600")

can = tkinter.Canvas(fenetre, width = 800, height = 600, bg = "black")
can.place(x = -2, y = 0)
#on découpe le canevas en quatre zones
horizontale = can.create_line(0, 300, 800, 300, width = 5, fill = "blue")
verticale = can.create_line(400, 0, 400, 600, width = 5, fill = "blue")
#on attend le clic de la souris sur la fenetre, pour déclencher la fonction couleur
fenetre.bind("<ButtonPress-1>", couleur)

fenetre.mainloop()