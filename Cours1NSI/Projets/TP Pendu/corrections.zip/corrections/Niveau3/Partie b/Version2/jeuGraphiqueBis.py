import tkinter
from random import randint
import listing

def choix(fichier):
    """Fonction qui crée une liste de mots obtenus dans le fichier words,
    puis en retourne un au hasard, sous forme d'une chaîne de caractères"""
    liste_mots = []
    with open(fichier,'r') as mon_fichier:
        for mot in mon_fichier:
            liste_mots.append(mot.rstrip('\n\r'))
    n = len(liste_mots)
    indice_mot = randint(0,n-1)
    return liste_mots[indice_mot]

def affiche_mot(mot,liste_lettres):
    """Fonction qui renvoie le mot avec les lettres du mot présentes dans la liste à leur place
    et des tirets pour les autres.
    entrées : le mot (str) ; la liste des lettres (list)
    sortie : un mot constitué de tirets et de lettres (str)
    """
    new_mot = ["-"]*(len(mot))
    for l in liste_lettres:
        for i in range(len(mot)):
            if l == mot[i]:
                new_mot[i] = l
    chaine =""
    for element in new_mot:
        chaine = chaine + element
    return chaine

def appartenir(mot,lettre):
    """Indique si la lettre donnée est présente au moins une fois dans le mot."""
    for l in mot:
        if l.lower() == lettre:
            return True
    return False

def envoi():
    """Fonction permettant de récupérer la lettre proposée par le joueur, puis de vérifier
    si elle fait partie du mot."""
    global echecs, trouver, num
    if (echecs < 6) and (trouver == False): #le nombre d'echecs doit être inférieur à 6 et on n'a pas encore trouvé le mot
        prop = lettre.get()           #on récupère la lettre proposée
        liste_propositions.append(prop) #on l'ajoute à la liste des lettres
        can.itemconfig(bilan, text = liste_propositions)
        affichage = affiche_mot(mot_a_deviner,liste_propositions)  #on modifie le mot à deviner en fonction de la lettre proposée
        can.itemconfig(le_mot, text = affichage)   #on affiche le mot
        if appartenir(mot_a_deviner, prop):    #si la lettre est dans le mot, on vérifie si on a trouvé le mot
            if affichage == mot_a_deviner:
                trouver = True
        else:
            echecs += 1     #sinon le nombre d'échecs augmente
            num += 1        #le numéro de l'image aussi
            new_img = tkinter.PhotoImage(file = "images/imag" + str(num) + ".png")
            can.itemconfig(pendu, image = new_img)   #on rajoute un élément au pendu
            can.update(pendu)    #provoque une erreur mais permet d'afficher le pendu
        lettre.delete(0,tkinter.END)    #on efface la saisie précédente
    if trouver == True:     #on a trouvé le mot
        liste.config(text="")   #on enlève le texte
        can.itemconfig(bilan, text = "Bien joué, vous avez trouvé le mot " + mot_a_deviner, fill = "orange2", font = ("Franklin Gothic Heavy", 15))
    if echecs == 6:        #on ne l'a pas trouvé
        liste.config(text="")   #on enlève le texte
        can.itemconfig(bilan, text = "Vous voilà pendu ! Il fallait trouver le mot " + mot_a_deviner, fill = "firebrick1", font = ("Mistral", 20))


def commencer():
    """On affiche les tirets du mot à deviner"""
    global mot_a_deviner
    mot_a_deviner = choix("words.txt")
    can.itemconfig(le_mot, text = affiche_mot(mot_a_deviner,[]))   #on affiche les tirets du mot à deviner
    lettre.focus()          #on place le curseur dans le champ de saisie


#Mise en place de l'interface graphique
fenetre = tkinter.Tk()
fenetre.title("jeu du Pendu")
fenetre.geometry("800x500")
can = tkinter.Canvas(fenetre, width = 800, height = 800, bg = "SteelBlue1")
can.place(x = -2, y = 0)

#Présentation du jeu
intro = tkinter.Label(can, text = "Vous devez proposer des lettres, sans accent, pour deviner un mot choisi au hasard.", fg = "Black",bg = "LightSkyBlue1", font = ("Onyx", 15))
intro.place(x = 50, y =20)
intro_suite = tkinter.Label(can, text = "Vous avez droit à 6 erreurs maximum.", fg = "Black", bg = "LightSkyBlue1", font = ("Onyx", 15))
intro_suite.place(x = 100, y = 60)

#Affichage du mot
presentation = tkinter.Label(can, text = "Mot à deviner", bg = "SteelBlue1",font = ("Onyx", 20))
presentation.place(x = 150, y = 150)
le_mot = can.create_text(200, 220, text = "", fill = "dodgerBlue3", font = ("Franklin Gothic Heavy",30))

#Proposition d'une lettre
description = tkinter.Label(can, text = "Veuillez proposer une lettre :", bg = "SteelBlue1",font = ("Onyx", 15))
description.place(x = 400, y = 200)
lettre = tkinter.Entry(can, bg = "SteelBlue2", width = 2, font = ("Times New Roman", 20))
lettre.place(x = 450, y = 250)

#envoie de la lettre
bouton = tkinter.Button(can, text = "Valider", bg = "LightSkyBlue2", font = ("Times New Roman", 12), command = envoi)
bouton.place(x = 500, y = 252)

#Bilan final et lettres proposées
liste = tkinter.Label(can, text = "Lettres proposées :", bg = "SteelBlue1",font = ("Onyx", 15))
liste.place(x = 280, y = 280)
bilan = can.create_text(350, 340, text = "", fill = "dodgerBlue3", font = ("Franklin Gothic Heavy",30))

#image du pendu
num = 1
fichier_img = tkinter.PhotoImage(file = "images/imag1.png")
pendu = can.create_image(700, 420, image = fichier_img)

#Initialisation des variables
echecs = 0
trouver = False
liste_propositions = []

#On lance le jeu
commencer()

fenetre.mainloop()