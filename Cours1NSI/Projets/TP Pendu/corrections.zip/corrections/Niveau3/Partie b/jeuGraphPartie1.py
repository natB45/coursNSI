import tkinter
from random import randint


def choix(fichier):
    """Fonction qui crée une liste de mots obtenus dans le fichier words,
    puis en retourne un au hasard, sous forme d'une chaîne de caractères"""
    liste_mots = []
    with open(fichier,'r') as mon_fichier:
        for mot in mon_fichier:
            liste_mots.append(mot.rstrip('\n\r'))
    n = len(liste_mots)
    indice_mot = randint(0,n-1)
    return liste_mots[indice_mot]

def affiche_mot(mot,liste_lettres):
    """Fonction qui renvoie le mot avec les lettres du mot présentes dans la liste à leur place
    et des tirets pour les autres.
    entrées : le mot (str) ; la liste des lettres (list)
    sortie : un mot constitué de tirets et de lettres (str)
    """
    new_mot = ["-"]*(len(mot))
    for l in liste_lettres:
        for i in range(len(mot)):
            if l == mot[i]:
                new_mot[i] = l
    chaine =""
    for element in new_mot:
        chaine = chaine + element
    return chaine

def appartenir(mot,lettre):
    """Indique si la lettre donnée est présente au moins une fois dans le mot."""
    for l in mot:
        if l.lower() == lettre:
            return True
    return False

def envoi():
    """Fonction permettant de récupérer la lettre proposée par le joueur, puis de vérifier
    si elle fait partie du mot."""
    pass

def commencer():
    """On affiche les tirets du mot à deviner"""
    pass


#Mise en place de l'interface graphique
fenetre = tkinter.Tk()
fenetre.title("jeu du Pendu")
fenetre.geometry("800x500")
can = tkinter.Canvas(fenetre, width = 800, height = 800, bg = "SteelBlue1")
can.place(x = -2, y = 0)

#Présentation du jeu
intro = tkinter.Label(can, text = "Vous devez proposer des lettres, sans accent, pour deviner un mot choisi au hasard.", fg = "Black",bg = "LightSkyBlue1", font = ("Onyx", 15))
intro.place(x = 50, y =20)
intro_suite = tkinter.Label(can, text = "Vous avez droit à 6 erreurs maximum.", fg = "Black", bg = "LightSkyBlue1", font = ("Onyx", 15))
intro_suite.place(x = 100, y = 60)

#Affichage du mot
presentation = tkinter.Label(can, text = "Mot à deviner", bg = "SteelBlue1",font = ("Onyx", 20))
presentation.place(x = 150, y = 150)
le_mot = can.create_text(200, 220, text = "", fill = "dodgerBlue3", font = ("Franklin Gothic Heavy",30))

#Proposition d'une lettre
description = tkinter.Label(can, text = "Veuillez proposer une lettre :", bg = "SteelBlue1",font = ("Onyx", 15))
description.place(x = 400, y = 200)
lettre = tkinter.Entry(can, bg = "SteelBlue2", width = 2, font = ("Times New Roman", 20))
lettre.place(x = 450, y = 250)

#envoie de la lettre
bouton = tkinter.Button(can, text = "Valider", bg = "LightSkyBlue2", font = ("Times New Roman", 12), command = envoi)
bouton.place(x = 500, y = 252)

#Bilan final et lettres proposées
liste = tkinter.Label(can, text = "Lettres proposées :", bg = "SteelBlue1",font = ("Onyx", 15))
liste.place(x = 280, y = 280)
bilan = can.create_text(350, 340, text = "", fill = "dodgerBlue3", font = ("Franklin Gothic Heavy",30))

#image du pendu
num = 1
fichier_img = tkinter.PhotoImage(file = "images/imag1.png")
pendu = can.create_image(700, 420, image = fichier_img)


#On lance le jeu
commencer()

fenetre.mainloop()