"""Ce programme permet de jouer au pendu. L'ordinateur choisi un mot au hasard
   dans un fichier texte de mots de 7 lettres, puis il représente le mot avec des tirets.
   On a droit à 6 erreurs au maximum.
"""
__author__ = ("Nathalie Bessonnet")
__date__ = "12/04/2020"

from random import randint
import listing
import tkinter    #on importe le module tkinter


#def montrer_mot(mot):
 #   """Fonction qui affiche le mot à deviner dans la fenetre"""

    #mot_a_trouver = tkinter.Label(can, text = mot, fg = "Black",font = 20)
    #mot_a_trouver.place(x = 250, y = 250)


def demander_nom():
    """Présente le jeu et affiche une zone où entrer son nom"""
    global zone_text, description, zone_text, bouton, jeu, jeu2    #variable globale que l'on peut modifier en dehors de cette fonction
    jeu = tkinter.Label(can, text = "Vous devez proposer des lettres, sans accent, pour deviner un mot choisi au hasard.", fg = "Black",font = ("Onyx", 15))
    jeu.place(x = 50, y =20)
    jeu2 = tkinter.Label(can, text = "Vous avez droit à 6 erreurs maximum.", fg = "Black",font = ("Onyx", 15))
    jeu2.place(x = 50, y = 50)
    description = tkinter.Label(can, text = "Quel est votre nom ?", fg = "Black",font = ("Onyx", 15))
    description.place(x = 200, y = 100)
    zone_text = tkinter.Entry(can, bg = "red", width = 10, font = ("Times New Roman", 15))
    zone_text.place(x = 350, y = 102)
    bouton = tkinter.Button(can, text = "Valider", font = ("Times New Roman", 12), command = affiche_nom)
    bouton.place(x = 490, y = 100)

def affiche_nom():
    """Place le nom du joueur en haut de la fenêtre"""
    global bouton2,nom_joueur
    nom_joueur = zone_text.get()
    nom = can.create_text(80, 20, text = nom_joueur, fill = "green", font = ("Century", 20))
    description.destroy()    #on détruit les widget devenu inutiles
    zone_text.destroy()
    bouton.destroy()
    jeu.destroy()
    jeu2.destroy()
    bouton2 = tkinter.Button(can, text = "Commencer", font = ("Times New Roman", 12), command = commencer)
    bouton2.place(x = 50, y = 200)


def commencer():
    """bouton pour commencer le jeu"""
    bouton2.destroy()
    can.update()
    jouer()

def jouer():
    global num
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    continuer = True
    #texte placé dans la fenêtre
    texte = can.create_text(200, 150, text = "Mot à deviner :", fill = "black", font = 20)
    mot_a_trouver = can.create_text(200, 200, text = "", fill = "black", font = 40)
    text_liste = can.create_text(200, 250, text = "Lettres déjà proposées :", fill = "black", font = 20)
    liste_lettres = can.create_text(250, 300, text = "", fill = "black", font = 20)
    text_echec =  can.create_text(500, 250, text = "Nombre d'echecs : ", fill = "black", font = 20)
    nb_echecs = can.create_text(600, 250, text = "0", fill = "black", font = 20)
    zone_reponse = can.create_text(450, 200, text = "", fill = "black", font = 40)
    while continuer:
        mot_a_deviner = choix("mots7.txt")
        affichage = affiche_mot(mot_a_deviner,[])  #on affiche le mot à deviner dans la fenetre
        can.itemconfig(mot_a_trouver, text = affichage)
        can.update()
        echecs = 0
        trouver = False
        liste_propositions = []
        while trouver == False and echecs != 6:
            proposition = input("Quelle lettre proposez-vous ? ")
            while proposition not in alphabet:
                proposition = input("Attention, proposition non valide. Donnez une nouvelle lettre : ")
            liste_propositions.append(proposition)
            affichage = affiche_mot(mot_a_deviner,liste_propositions)
            if appartenir(mot_a_deviner,proposition):
                can.itemconfig(mot_a_trouver, text = affichage)
                can.update()    #on affiche le mot à deviner dans la fenetre
                can.itemconfig(zone_reponse, text = "")
                can.update()
                if affichage == mot_a_deviner:
                    trouver = True
            else:
                echecs += 1
                num +=1
                can.itemconfig(zone_reponse, text = "Cette lettre n'est pas présente !")
                can.update()
                new_fichier_img = tkinter.PhotoImage(file = "images/im"+str(num)+".png")
                can.itemconfig(pendu, image = new_fichier_img)
                can.itemconfig(mot_a_trouver, text = affichage)
                can.update()  #on affiche le mot à deviner dans la fenetre
            l =""
            for el in liste_propositions:
                l = l + el + " ; "
            can.itemconfig(liste_lettres, text = l)
            can.update()
            can.itemconfig(nb_echecs, text = str(echecs))
            can.update()
        if trouver == True:
            bilan = can.create_text(300, 380, text = "Bien joué, vous avez trouvé le mot " + mot_a_deviner, fill = "black", font = 20)
            can.update()
            infos = {"nom" : nom_joueur, "victoires" : 1, "nbre_parties" : 1}   #on stocke la victoire du joueur dans un dictionnaire
        else:
            bilan = can.create_text(300,380, text = "Vous voilà pendu ! Il fallait trouver le mot " + mot_a_deviner, fill = "black", font = 20)
            can.update()
            infos = {"nom" : nom_joueur, "victoires" : 0, "nbre_parties" : 1}   #on stocke sa défaite
        listing.enregistrer_score("scores.csv",infos)      #on ajoute le score du joueur au fichier
        jouer = input ("Voulez-vous rejouer ? o/n ")
        if jouer.lower() == "n":
            continuer = False
    vict, parties = listing.afficher_score("scores.csv",nom_joueur)  #on récupère le nombre de victoires et de parties du joueur
    print("Vous avez gagné", vict, "parties sur", parties)

def appartenir(mot,lettre):
    """Indique si la lettre donnée est présente au moins une fois dans le mot."""
    for l in mot:
        if l.lower() == lettre:
            return True
    return False

def choix(fichier):
    """Fonction qui crée une liste de mots obtenus dans le fichier,
    puis en retourne un au hasard, sous forme d'une chaîne de caractères"""
    liste_mots = []
    with open(fichier,'r') as mon_fichier:
        for mot in mon_fichier:
            liste_mots.append(mot.rstrip('\n\r'))
    n = len(liste_mots)
    indice_mot = randint(0,n-1)
    return liste_mots[indice_mot]

def affiche_mot(mot,liste_lettres):
    """Fonction qui renvoie le mot avec les lettres du mot présentes dans la liste à leur place
    et des tirets pour les autres.
    entrées : le mot (str) ; la liste des lettres (list)
    sortie : un mot constitué de tirets et de lettres (str)
    """
    new_mot = ["-"]*(len(mot))
    for l in liste_lettres:
        for i in range(len(mot)):
            if l == mot[i]:
                new_mot[i] = l
    chaine =""
    for element in new_mot:
        chaine = chaine + element
    return chaine



if __name__ == "__main__":
    fenetre = tkinter.Tk()          #Mise en place de la fenêtre graphique
    fenetre.title("jeu du Pendu")
    fenetre.geometry("800x800")
    #On pose un caneva sur la fenetre, pour dessiner dessus
    can = tkinter.Canvas(fenetre, width = 800, height = 800, bg = "powder blue")
    can.place(x = -2, y = 0)

    num = 1  #numéro de l'image
    fichier_img = tkinter.PhotoImage(file = "images/im1.png")
    pendu = can.create_image(700, 400, image = fichier_img)
    demander_nom()

    fenetre.mainloop()
