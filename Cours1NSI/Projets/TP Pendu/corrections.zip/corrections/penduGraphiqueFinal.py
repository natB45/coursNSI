"""Ce programme permet de jouer au pendu. L'ordinateur choisi un mot au hasard
   dans un fichier texte de mots de 7 lettres, puis il représente le mot avec des tirets.
   On a droit à 6 erreurs au maximum.
"""
__author__ = ("Nathalie Bessonnet")
__date__ = "12/04/2020"
import tkinter #on importe le module tkinter
from random import randint
import listing

def appartenir(mot,lettre):
    """Indique si la lettre donnée est présente au moins une fois dans le mot."""
    for l in mot:
        if l.lower() == lettre:
            return True
    return False

def choix(fichier):
    """Fonction qui crée une liste de mots obtenus dans le fichier,
    puis en retourne un au hasard, sous forme d'une chaîne de caractères"""
    liste_mots = []
    with open(fichier,'r') as mon_fichier:
        for mot in mon_fichier:
            liste_mots.append(mot.rstrip('\n\r'))
    n = len(liste_mots)
    indice_mot = randint(0,n-1)
    return liste_mots[indice_mot]

def affiche_mot(mot,liste_lettres):
    """Fonction qui renvoie le mot avec les lettres du mot présentes dans la liste à leur place
    et des tirets pour les autres.
    entrées : le mot (str) ; la liste des lettres (list)
    sortie : un mot constitué de tirets et de lettres (str)
    """
    new_mot = ["-"]*(len(mot))
    for l in liste_lettres:
        for i in range(len(mot)):
            if l == mot[i]:
                new_mot[i] = l
    chaine =""
    for element in new_mot:
        chaine = chaine + element
    return chaine

def rejouer(evt):
    """Fonction permettant de savoir si le joueur veut rejouer ou non"""
    global rep
    rep = evt.char.lower()




def gestion_nom():
    """Enregistrement et affichage du nom du joueur"""
    global num                     #on va modifier la variable déclarée dans le corps principal du programme
    nom_joueur = zone_text.get()   #on récupère le nom du joueur pour l'afficher
    nom = can.create_text(400, 40, text = nom_joueur, fill = "dark orange3", font = ("Franklin Gothic Heavy", 20))
    demande.destroy()    #on détruit les widgets devenu inutiles
    zone_text.destroy()
    bouton.destroy()
    intro.destroy()
    intro_suite.destroy()
    can.update()
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    continuer = True
    #Afficher le mot
    texte = can.create_text(200, 150, text = "Mot à deviner :", fill = "black", font = ("Rockwell Extra",20))
    #Zone où afficher le mot
    mot_a_trouver = can.create_text(200, 200, text = "", fill = "dodgerBlue3", font = ("Franklin Gothic Heavy",35))
    #Afficher les lettres proposées
    text_liste = can.create_text(200, 270, text = "Lettres déjà proposées :", fill = "Purple", font = 20)
    #Zone où afficher la liste
    liste_lettres = can.create_text(230, 320, text = "", fill = "black", font = 20)
    #Afficher le nombre d'échecs
    text_echec =  can.create_text(600, 270, text = "Nombre d'echecs : ", fill = "red", font = 20)
    #Zone où afficher ce nombre
    nb_echecs = can.create_text(690, 270, text = "0", fill = "black", font = 20)
    #Commentaire sur la présence ou non de la lettre
    zone_reponse = can.create_text(550, 200, text = "", fill = "black", font = 40)
    while continuer:
        mot_a_deviner = choix("words.txt")
        affichage = affiche_mot(mot_a_deviner,[])  #on affiche le mot à deviner dans la fenetre
        can.itemconfig(mot_a_trouver, text = affichage)
        can.update()
        echecs = 0
        trouver = False
        liste_propositions = []
        while trouver == False and echecs != 6:
            proposition = input("Quelle lettre proposez-vous ? ")
            while proposition not in alphabet:
                proposition = input("Attention, proposition non valide. Donnez une nouvelle lettre : ")
            liste_propositions.append(proposition)
            affichage = affiche_mot(mot_a_deviner,liste_propositions)
            if appartenir(mot_a_deviner,proposition):
                can.itemconfig(mot_a_trouver, text = affichage)    #on affiche le mot à deviner dans la fenetre
                can.update()
                can.itemconfig(zone_reponse, text = "")            #pas de commentaire
                can.update()
                if affichage == mot_a_deviner:
                    trouver = True
            else:
                echecs += 1                                       #on indique que la lettre n'est pas présente
                num +=1                                           #on augmente le numéro de l'image
                can.itemconfig(zone_reponse, text = "Cette lettre n'est pas présente !")
                can.update()
                new_fichier_img = tkinter.PhotoImage(file = "images/imag"+str(num)+".png")  #on charge l'image suivante
                can.itemconfig(pendu, image = new_fichier_img)     #on change l'image du pendu
                can.itemconfig(mot_a_trouver, text = affichage)    #on affiche le mot à deviner dans la fenetre
                can.update()
            l =""                 #création d'une chaine de caractère avec les lettres proposées
            for el in liste_propositions:
                l = l + el + " ; "
            can.itemconfig(liste_lettres, text = l)   #affichage des lettres proposées
            can.update()
            can.itemconfig(nb_echecs, text = str(echecs))    #affichage du nombre d'échecs
            can.update()
        if trouver == True:
            bilan = can.create_text(310, 360, text = "Bien joué, vous avez trouvé le mot " + mot_a_deviner, fill = "orange2", font = ("Franklin Gothic Heavy", 20))     #Afficher la victoire
            can.update()
            infos = {"nom" : nom_joueur, "victoires" : 1, "nbre_parties" : 1}
        else:
            bilan = can.create_text(310,360, text = "Vous voilà pendu ! Il fallait trouver le mot " + mot_a_deviner, fill = "firebrick1", font = ("Mistral", 20))  #Afficher l'échec
            can.update()
            infos = {"nom" : nom_joueur, "victoires" : 0, "nbre_parties" : 1}
        listing.enregistrer_score("scores.csv",infos)
        jouer = input ("Voulez-vous rejouer ? o/n ")
        if jouer.lower() == "n":
            continuer = False
        else:
            can.delete(bilan)     #si on rejoue, on efface le bilan et le commentaire
            can.delete(zone_reponse)
    vict, parties = listing.afficher_score("scores.csv",nom_joueur)
    print("Vous avez gagné", vict, "parties sur", parties)


if __name__ == "__main__":
    fenetre = tkinter.Tk()          #Mise en place de la fenêtre graphique
    fenetre.title("jeu du Pendu")
    fenetre.geometry("800x500")    #On pose un caneva sur la fenetre, pour dessiner dessus
    can = tkinter.Canvas(fenetre, width = 800, height = 800, bg = "SteelBlue1")
    can.place(x = -2, y = 0)
    #Présentation du jeu
    intro = tkinter.Label(can, text = "Vous devez proposer des lettres, sans accent, pour deviner un mot choisi au hasard.", fg = "Black",bg = "LightSkyBlue1", font = ("Onyx", 15))
    intro.place(x = 50, y =20)
    intro_suite = tkinter.Label(can, text = "Vous avez droit à 6 erreurs maximum.", fg = "Black", bg = "LightSkyBlue1", font = ("Onyx", 15))
    intro_suite.place(x = 100, y = 60)
    can.update()

    #image du pendu
    num = 1  #numéro de l'image
    fichier_img = tkinter.PhotoImage(file = "images/imag1.png")
    pendu = can.create_image(700, 400, image = fichier_img)


    #Nom du joueur
    demande = tkinter.Label(can, text = "Quel est votre nom ?", bg = "SteelBlue1",font = ("Onyx", 15))
    demande.place(x = 200, y = 200)
    zone_text = tkinter.Entry(can, bg = "SteelBlue2", width = 10, font = ("Times New Roman", 15))
    zone_text.place(x = 350, y = 202)
    bouton = tkinter.Button(can, text = "Valider", bg = "LightSkyBlue2", font = ("Times New Roman", 12), command = gestion_nom)
    bouton.place(x = 490, y = 200)
    can.update()


    fenetre.mainloop()