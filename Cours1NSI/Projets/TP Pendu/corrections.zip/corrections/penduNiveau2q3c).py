def afficher_score(nom_fichier,nom):
    """Fonction qui permet de récupérer le score d'un joueur en fin de partie.
    Entrées : le fichier csv des scores et le nom du joueur (str)
    Sortie : un tuple avec le nombre de victoires et le nombre de parties jouées
    """
    liste_scores = charger_scores(nom_fichier)
    for dico in liste_scores:   #on cherche le joueur dans la fichier
        if dico["nom"] == nom:
            return (dico["victoires"], dico["nbre_parties"])