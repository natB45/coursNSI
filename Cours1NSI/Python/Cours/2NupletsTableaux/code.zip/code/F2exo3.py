liste_carres = [i*i for i in range(100)]
print(liste_carres,end= "")