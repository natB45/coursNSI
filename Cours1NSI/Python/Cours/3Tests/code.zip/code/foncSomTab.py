def f(t):
    s = 0
    for i in range(len(t)):
        s += t[i]
    return s