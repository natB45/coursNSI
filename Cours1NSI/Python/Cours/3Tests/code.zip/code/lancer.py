import random
def lance_de():
    """Cette fonction choisit un nombre au hasard entre
    1 et 6, et retourne sa valeur"""
    return random.randint(1,6)