def deb_mot_egal_fin(mot):
    pass

assert deb_mot_egal_fin("rouler") == True
assert deb_mot_egal_fin("chien") == False
assert deb_mot_egal_fin("") == None
assert deb_mot_egal_fin("Ana") == True
assert deb_mot_egal_fin(" ici") == False