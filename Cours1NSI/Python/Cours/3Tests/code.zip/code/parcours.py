def parcours(liste):
    """Cette fonction prend une liste en paramètre
    pour afficher successivement chacun de ses éléments"""
    pass