import dectobin

def somme(a,b):
    a = str(a)
    b = str(b)
    n = len(a)
    m = len(b)
    if n <= m:
        max = m
    else:
        max = n
    