var nom = prompt("Quel est votre nom ?");
alert("Bonjour " + nom);
