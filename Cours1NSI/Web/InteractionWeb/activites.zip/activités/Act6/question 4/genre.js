var sexe=prompt("Quel est votre sexe ? H/F");
if (sexe==="H"){
    alert("Bonjour Monsieur !");
}
if (sexe==="F"){
    alert("Bonjour Madame !");
}