function carre(nombre){
  return nombre**2;            
}

var n=parseInt(prompt("Donner un nombre :"));
alert(carre(n));