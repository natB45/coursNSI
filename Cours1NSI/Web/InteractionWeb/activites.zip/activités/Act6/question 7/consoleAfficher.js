function affiche(n){
  console.log("Bienvenue dans mon monde "+n);            
}

var nom=prompt("Quel est ton nom petit padawan ?");
affiche(nom);