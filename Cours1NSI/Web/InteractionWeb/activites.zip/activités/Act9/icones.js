function theme(x){
    if (x===1){
        document.body.style.backgroundImage = "url('alien.png')"; 
    }
    if (x===2){
        document.body.style.backgroundImage = "url('human.png')"; 
    }
    if (x===3){
        document.body.style.backgroundImage = "url('unicorn.png')"; 
    }
}